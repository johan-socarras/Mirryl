Mirryl - MPL-2.0 source code
=============================

This folder contains the complete, unmodified source code of the one
component Mirryl links under the Mozilla Public License 2.0 (see
Mirryl's third-party notices, Section 2.4):

    option-ext 0.2.0
    Copyright (c) Simon Ochsenreither
    https://crates.io/crates/option-ext/0.2.0

It is the exact package as published on crates.io - Cargo.toml,
LICENSE, README and source files - with nothing changed, added or
removed beyond Cargo-internal bookkeeping files that carry no
license-relevant content.

It is bundled here so that source availability does not depend on any
external site remaining online.
